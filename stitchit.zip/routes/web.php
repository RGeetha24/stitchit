<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Site\HomeController;
use App\Http\Controllers\Site\ExtrasController;
use App\Http\Controllers\Site\OrderController;
use App\Http\Controllers\Site\ProfileController;
use App\Http\Controllers\Site\MeasurementController;

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\RouteController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\RevenueController;

Route::prefix('server-commands')->group(function () {
    Route::get('optimize', function () {
        \Artisan::call('optimize');
        \Artisan::call('config:clear');
        \Artisan::call('view:clear');
        \Artisan::call('route:cache');
        \Artisan::call('route:clear');
        dd("Done!");
    });
});

// Route::get('/', function () {
//     return view('site.index');
// })->name('home');
//SITE HOME ROUTE
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/topwear', [HomeController::class, 'topwear'])->name('topwear');
Route::get('/faq', [ExtrasController::class, 'faq'])->name('faq');
Route::get('/about', [ExtrasController::class, 'about'])->name('about');
Route::get('/notification', [ExtrasController::class, 'notification'])->name('notification');
 


//Order
Route::get('/order-history', [OrderController::class, 'orderHistory'])->name('order.history');
Route::get('/order-details/{id}', [OrderController::class, 'orderDetails'])->name('order.details');
Route::get('/feedback/{id}', [OrderController::class, 'feedback'])->name('order.feedback');
Route::get('/track-order/{id}', [OrderController::class, 'trackOrder'])->name('order.track');
Route::get('/cart', [OrderController::class, 'cart'])->name('order.cart');
Route::get('/checkout', [OrderController::class, 'checkout'])->name('order.checkout');

//Measurement Options
Route::get('/measurement-options', [MeasurementController::class, 'measurementOptions'])->name('measurementOptions');
Route::get('/garment-details', [MeasurementController::class, 'garmentDetails'])->name('garmentDetails');
Route::get('/manual-measurement', [MeasurementController::class, 'manualMeasurement'])->name('manualMeasurement');//
Route::get('/fit-sample-cloth', [MeasurementController::class, 'fitSampleCloth'])->name('fitSampleCloth');//
Route::get('/alteration-instruction', [MeasurementController::class, 'alterationInstruction'])->name('alterationInstruction');//
Route::get('/checkout', [MeasurementController::class, 'checkout'])->name('checkout');

//PROFILE
Route::get('/accounts', [ProfileController::class, 'accounts'])->name('accounts');
Route::get('/subscription', [ProfileController::class, 'subscription'])->name('subscription');
Route::get('/monthly-subscription', [ProfileController::class, 'monthlySubscription'])->name('monthlySubscription');//
Route::get('/quarter-subscription', [ProfileController::class, 'quarterSubscription'])->name('quarterSubscription');//
Route::get('/year-subscription', [ProfileController::class, 'yearSubscription'])->name('yearSubscription');//    
Route::get('/refer', [ProfileController::class, 'referAndEarn'])->name('refer');
Route::get('/donate', [ProfileController::class, 'donateClothes'])->name('donate');
Route::get('/donation-history', [ProfileController::class, 'donationHistory'])->name('donationHistory');
Route::get('/track-donation', [ProfileController::class, 'trackDonation'])->name('trackDonation');
Route::get('/view-profile', [ProfileController::class, 'viewProfile'])->name('viewProfile');
Route::get('/settings', [ProfileController::class, 'settings'])->name('settings');
Route::get('/wallet', [ProfileController::class, 'wallet'])->name('wallet');



// Admin Routes with 'admin' prefix 
Route::prefix('admin')->as('admin.')->group(function () {
    Route::get('/login', function () {
        return view('admin.login');
    })->name('login');
    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/orders', [AdminOrderController::class, 'orders'])->name('orders');
    Route::get('/pickup',[AdminOrderController::class, 'pickup'])->name('pickup');
    Route::get('/routeOptimize', [RouteController::class, 'routeOptimize'])->name('routeOptimize');
    Route::get('/tailor',[UserController::class, 'tailor'])->name('tailor');
    Route::get('/account',[UserController::class, 'account'])->name('account');
    Route::get('/user_edit',[UserController::class, 'userEdit'])->name('userEdit');
    Route::get('/financial',[RevenueController::class, 'financial'])->name('financial');
    Route::get('/report',[RevenueController::class, 'report'])->name('report');
});
