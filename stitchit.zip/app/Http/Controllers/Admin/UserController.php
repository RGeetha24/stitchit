<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function tailor()
    {
        return view('admin.tailor');
    }

    public function account()
    {
        return view('admin.account');
    }

    public function userEdit()
    {
        return view('admin.userEdit');
    }   
}
