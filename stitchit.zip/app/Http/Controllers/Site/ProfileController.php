<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    public function accounts()
    {
        return view('site.profile.accounts');
    }

    public function subscription()
    {
        return view('site.profile.subscription');
    }

    public function monthlySubscription()
    {
        return view('site.profile.monthlySubscription');
    }

    public function quarterSubscription()
    {
        return view('site.profile.quarterSubscription');
    }

    public function yearSubscription()
    {
        return view('site.profile.yearSubscription');
    }

    public function referAndEarn()
    {
        return view('site.profile.referAndEarn');
    }

    public function donateClothes()
    {
        return view('site.profile.donateClothes');
    }

    public function viewProfile()
    {
        return view('site.profile.viewProfile');
    }

    public function donationHistory()
    {
        return view('site.profile.donationHistory');
    }

    public function settings()
    {
        return view('site.profile.settings');
    }

    public function wallet()
    {
        return view('site.profile.wallet');
    }

    public function trackDonation()
    {
        return view('site.profile.trackDonation');
    }
}
