@include('site.layout.header')
@yield('content')
@include('site.layout.footer')