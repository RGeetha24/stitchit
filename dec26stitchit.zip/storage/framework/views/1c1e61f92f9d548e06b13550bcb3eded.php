
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="material-icons back-icon" style="margin-bottom: 30px;">
      <i class="fas fa-arrow-left"></i>
    </div>

    <div class="account-header">
      <i class="fas fa-user-circle"></i>
      <h1>Account</h1>
    </div>

    <div class="menu-item" onclick="window.location.href='<?php echo e(route('viewProfile')); ?>'">
      <div class="menu-label">
        <i class="fas fa-user"></i>
        View Profile
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>


    <div class="menu-item" onclick="window.location.href='<?php echo e(route('order.cart')); ?>'">
      <div class="menu-label">
        <i class="fas fa-shopping-cart"></i>
        Cart
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>

    <div class="menu-item" onclick="window.location.href='<?php echo e(route('order.history')); ?>'">
      <div class="menu-label">
        <i class="fas fa-clock-rotate-left"></i>
        Order history
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>

    <div class="menu-item" onclick="window.location.href='<?php echo e(route('donationHistory')); ?>'">
      <div class="menu-label">
        <i class="fas fa-receipt"></i>
        Donation history
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>

    <div class="menu-item" onclick="window.location.href='<?php echo e(route('settings')); ?>'">
      <div class="menu-label">
        <i class="fas fa-cog"></i>
        Settings
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>


    <div class="menu-item" onclick="window.location.href='<?php echo e(route('faq')); ?>'">
      <div class="menu-label">
        <i class="fas fa-question-circle"></i>
        FAQs
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>
    <div class="menu-item" onclick="window.location.href='<?php echo e(route('wallet')); ?>'">
      <div class="menu-label">
        <i class="fas fa-wallet"></i>
        Wallet
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>


    <div class="menu-item" onclick="window.location.href='<?php echo e(route('about')); ?>'">
      <div class="menu-label">
        <i class="fas fa-info-circle"></i>
        About Us
      </div>
      <i class="fas fa-chevron-right arrow-icon"></i>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout.submain', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\1Dreamzcoder\stitchit\resources\views/site/profile/accounts.blade.php ENDPATH**/ ?>