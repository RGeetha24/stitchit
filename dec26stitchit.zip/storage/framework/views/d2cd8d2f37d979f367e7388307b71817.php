<!-- Top Bar -->
<div class="topbar">

    <button class="toggle-btn" id="toggleBtn">&#9776;</button>

    <input type="text" placeholder="Search here...">

    <div class="top-icons">
        <img src='<?php echo e(url("admin/assets/images/bell.png")); ?>' class="top-icon">
        <img src='<?php echo e(url("admin/assets/images/message.png")); ?>' class="top-icon">
    </div>

    <div class="user-info" id="userInfo">
        <img src='<?php echo e(url("admin/assets/images/profile.png")); ?>' class="avatar">
        <div class="user-text">
            <h4><?php echo e(Auth::user()->name); ?></h4>
            <span>Studio Manager</span>
        </div>

        <!-- Dropdown -->
        <div class="user-dropdown" id="userDropdown">
            <a href="<?php echo e(route('admin.account')); ?>">My Account</a>
            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>
            </form>
        </div>
    </div>



</div><?php /**PATH C:\xampp\htdocs\dreamz\stitchit\resources\views/admin/layout/topbar.blade.php ENDPATH**/ ?>