

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main">
    <?php echo $__env->make('admin.layout.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Category Page Content -->
    <div class="category-page" style="margin-top: 10px;">

        
        <?php if(session('success') || session('error')): ?>
            <div id="toast"
                 class="toast <?php echo e(session('error') ? 'toast-error' : 'toast-success'); ?>">
                <?php echo e(session('success') ?? session('error')); ?>

            </div>
        <?php endif; ?>
    
        <!-- Content Grid -->
        <div class="category-content-grid">

            <!-- LEFT SECTION -->
            <div class="left">

                <!-- Recent Header with 3 Dots -->
                <div class="table-container">
                    <div class="recent-header" style="display: flex; align-items: center; justify-content: space-between;">
                        <h1>Main Category</h1>
                        <a href="<?php echo e(route('admin.category.create')); ?>" class="refresh-btn">Add Category</a>
                    </div>

                    <table id="orderTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Slug</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->slug); ?></td>
                                    <td>
                                        <?php if($category->status): ?>
                                            <span class="status received">Active</span>
                                        <?php else: ?>
                                            <span class="status progress">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div style="display:flex; gap:8px; align-items:center;">
                                            <button
                                                type="button"
                                                class="icon-btn view-category-btn"
                                                data-name="<?php echo e($category->name); ?>"
                                                data-description="<?php echo e($category->description); ?>"
                                                data-status="<?php echo e($category->status ? 'Active' : 'Inactive'); ?>"
                                                data-image="<?php echo e($category->image ? asset('uploads/category/'.$category->image) : ''); ?>"
                                            >
                                                <i class="ri-eye-line"></i>
                                            </button>
                                            <a href="<?php echo e(route('admin.category.edit', $category->id)); ?>" title="Edit"><i class="ri-edit-line"></i></a>
                                            <form action="<?php echo e(route('admin.category.destroy', $category->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this category?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" title="Delete" style="background:none;border:none;padding:0;cursor:pointer;color:inherit;">
                                                    <i class="ri-delete-bin-line" style="color:#c00;"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" style="text-align:center;">No categories found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php if($categories->hasPages()): ?>
                        <div class="pagination">
                            <?php echo e($categories->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>

            </div>

        </div>
    </div>
    <!-- Category Page Content -->
</div>

<!-- View Category Modal -->
<div id="categoryViewModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalCategoryName">Category Details</h3>
            <button type="button" id="closeCategoryModal" class="modal-close">&times;</button>
        </div>
        <div class="modal-body">
            <p><strong>Name:</strong> <span id="modalCategoryNameText"></span></p>
            <p><strong>Status:</strong> <span id="modalCategoryStatus"></span></p>
            <p><strong>Description:</strong></p>
            <p id="modalCategoryDescription"></p>
            <div id="modalCategoryImageWrapper" style="margin-top:12px; display:none;">
                <p><strong>Image:</strong></p>
                <img id="modalCategoryImage" src="" alt="Category Image" style="max-width:100%; border-radius:8px;">
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Toast auto-hide
        const toast = document.getElementById('toast');
        if (toast) {
            setTimeout(() => {
                toast.style.opacity = '0';
                setTimeout(() => toast.style.display = 'none', 300);
            }, 2500);
        }

        const modal = document.getElementById('categoryViewModal');
        const closeBtn = document.getElementById('closeCategoryModal');
        const nameEl = document.getElementById('modalCategoryName');
        const nameTextEl = document.getElementById('modalCategoryNameText');
        const statusEl = document.getElementById('modalCategoryStatus');
        const descEl = document.getElementById('modalCategoryDescription');
        const imgWrapperEl = document.getElementById('modalCategoryImageWrapper');
        const imgEl = document.getElementById('modalCategoryImage');

        document.querySelectorAll('.view-category-btn').forEach(btn => {
            btn.addEventListener('click', function () {
                const name = this.getAttribute('data-name') || '';
                const status = this.getAttribute('data-status') || '';
                const description = this.getAttribute('data-description') || '—';
                const image = this.getAttribute('data-image') || '';

                nameEl.textContent = name;
                nameTextEl.textContent = name;
                statusEl.textContent = status;
                descEl.textContent = description;

                if (image) {
                    imgEl.src = image;
                    imgWrapperEl.style.display = 'block';
                } else {
                    imgEl.src = '';
                    imgWrapperEl.style.display = 'none';
                }

                modal.style.display = 'flex';
            });
        });

        function closeModal() {
            modal.style.display = 'none';
        }

        closeBtn.addEventListener('click', closeModal);
        modal.addEventListener('click', function (e) {
            if (e.target === modal) {
                closeModal();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamz\stitchit\resources\views/admin/category/index.blade.php ENDPATH**/ ?>