

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main">
    <?php echo $__env->make('admin.layout.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="category-page" style="margin-top: 10px;">
        <div class="table-container">
            <div class="recent-header" style="flex-direction: row; align-items: center; justify-content: space-between;">
                <h1>Edit Main Category</h1>
                <a href="<?php echo e(route('admin.category.index')); ?>" class="refresh-btn">Back to List</a>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST"
                  action="<?php echo e(route('admin.category.update', $category->id)); ?>"
                  enctype="multipart/form-data"
                  class="category-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="cat-grid">
                    <div class="box">
                        <h4>Basic Details</h4>
                        <div class="form-group">
                            <label for="name">Name *</label>
                            <input
                                type="text"
                                id="name"
                                name="name"
                                value="<?php echo e(old('name', $category->name)); ?>"
                                required
                                placeholder="e.g., Men, Women, Kids">
                        </div>
                        <div class="form-group">
                            <label for="slug">Slug *</label>
                            <input
                                type="text"
                                id="slug"
                                name="slug"
                                value="<?php echo e(old('slug', $category->slug)); ?>"
                                required
                                placeholder="e.g., men, women, kids">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea
                                id="description"
                                name="description"
                                rows="4"
                                placeholder="Short description (optional)"><?php echo e(old('description', $category->description)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="image">Image</label>
                            <input type="file" id="image" name="image" accept="image/*">
                            <?php if($category->image): ?>
                                <div style="margin-top:8px;">
                                    <p style="margin:0 0 4px;"><strong>Current Image:</strong></p>
                                    <img src="<?php echo e(asset('uploads/category/'.$category->image)); ?>"
                                         alt="Category Image"
                                         style="max-width: 140px; border-radius: 8px;">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="box">
                        <h4>SEO & Status</h4>
                        <div class="form-group">
                            <label for="meta_title">Meta Title</label>
                            <input
                                type="text"
                                id="meta_title"
                                name="meta_title"
                                value="<?php echo e(old('meta_title', $category->meta_title)); ?>">
                        </div>
                        <div class="form-group">
                            <label for="meta_description">Meta Description</label>
                            <textarea
                                id="meta_description"
                                name="meta_description"
                                rows="3"><?php echo e(old('meta_description', $category->meta_description)); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="meta_keywords">Meta Keywords</label>
                            <input
                                type="text"
                                id="meta_keywords"
                                name="meta_keywords"
                                value="<?php echo e(old('meta_keywords', $category->meta_keywords)); ?>"
                                placeholder="Comma separated">
                        </div>
                        <div class="form-group inline">
                            <div>
                                <label for="status">Status</label>
                                <select id="status" name="status">
                                    <option value="1" <?php echo e(old('status', $category->status) == 1 ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(old('status', $category->status) == 0 ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                            <div>
                                <label for="sort_order">Sort Order</label>
                                <input
                                    type="number"
                                    id="sort_order"
                                    name="sort_order"
                                    value="<?php echo e(old('sort_order', $category->sort_order)); ?>"
                                    min="0">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="save-cat-btn">Update Category</button>
                    <a href="<?php echo e(route('admin.category.index')); ?>" class="small-btn">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dreamz\stitchit\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>